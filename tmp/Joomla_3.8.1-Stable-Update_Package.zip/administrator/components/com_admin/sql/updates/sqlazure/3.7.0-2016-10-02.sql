ALTER TABLE [#__session] ALTER COLUMN [client_id] [tinyint] NULL;
